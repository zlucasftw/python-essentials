#! /usr/bin/env python3

""" module: beta """


def funB():
    return "Beta"


if __name__ == "__main__":
    print("I prefer to be a module.")
